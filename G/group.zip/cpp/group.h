#ifndef GROUP_H

bool is_abelian(int n);
int fuse_ball(int a, int b);

#endif // GROUP_H
