#ifndef GROUP_H

bool is_abelian(int n);
int compute(int a, int b);

#endif // GROUP_H
