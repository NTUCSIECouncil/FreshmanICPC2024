#if __has_include("lib0026.h")
#include "lib0026.h"
#else
#include "group.h"
#endif

bool is_abelian(int n)
{
    int c = fuse_ball(1, 2);
    int d = fuse_ball(2, 3);

    return true;
}
