#include "group.h"


bool is_abelian(int n)
{
    int c = compute(1, 2);
    int d = compute(2, 3);

    return true;
}
